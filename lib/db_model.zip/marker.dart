class Marker {
  Marker(
      {this.id,
        required this.lati,
        required this.longi,
        required this.place,
      });

  int? id;
  double lati;
  double longi;
  String place;

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'lati' : lati,
      'longi' : longi,
      'place' : place,
    };
  }
}