
import 'package:my_tiny_map/db_model/marker.dart';
import 'package:my_tiny_map/db_repository/sql_database.dart';
import 'package:sqflite/sqflite.dart';

class SqlMarkerCRUD {

  void insert(Marker marker) async {
    var db = await SqlDataBase.instance.database;
    marker.id = await db?.insert('marker', marker.toMap());
  }

  //현재 선택한 위도,경도의 markerid값.
  Future<int> MarkerId(double lati,double longti) async {
    var db = await SqlDataBase.instance.database;
    List<Map> result = await db.rawQuery(
        'SELECT id FROM marker WHERE lati =? AND longti =? ', [lati,longti]);
    return result[0]['id'];
  }

  //마커 삭제
  void deleteMarker(double lati,double longti) async{
    var db = await SqlDataBase.instance.database;
    await db.rawDelete('DELETE FROM marker WHERE lati = ? AND longti =? ',[lati,longti]);
  }
}