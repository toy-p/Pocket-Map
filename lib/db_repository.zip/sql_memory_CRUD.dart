import 'package:my_tiny_map/db_model/memory_model.dart';
import 'package:my_tiny_map/db_repository/sql_database.dart';

class SqlMemoryCRUD {

  //삽입
  void insert(Memory memory) async {
    var db = await SqlDataBase.instance.database;
    memory.idx = await db?.insert('memory', memory.toMap());
  }
  //수정(여기선 content말곤 수정 할 사항 없음)
  //이미지 추가 삭제는 sql_picture_CRUD에서 처리해야함.
  void update(String content,int memory_idx) async{
    var db = await SqlDataBase.instance.database;
    await db.rawUpdate('UPDATE memory SET contents = ? WHERE memory_idx =? ',[content,memory_idx]);
  }
  //해당 마커의 추억 리스트.
  Future<List<Map>> MemoryDataMap(int marker_idx) async{
    var db = await SqlDataBase.instance.database;
    List<Map> result = await db.rawQuery(
        'SELECT * FROM memory WHERE marker_idx = ?', [marker_idx]);
    return result;
  }
  //마커에 속한 메모리 삭제
  void deleteMemory(int memory_idx) async{
    var db = await SqlDataBase.instance.database;
    await db.rawDelete('DELETE FROM memory WHERE memory_idx = ? ',[memory_idx]);
  }
  //마커 삭제
  void deleteMarkerMemory(int marker_idx) async{
    var db = await SqlDataBase.instance.database;
    await db.rawDelete('DELETE FROM memory WHERE marker_idx = ?',[marker_idx]);
  }
}